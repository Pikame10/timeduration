/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thibault
 */
public  class TimeDuration {
     private int heures;
   private int minutes ;// de 0 à 59
   private int secondes ; // de 0 à 59
    
     public TimeDuration(){
       heures = 0 ;
       minutes = 0 ;
       secondes = 0 ;
   }
    
     
      public TimeDuration(int h, int m, int s){// initialise heures, minutes,                          
       heures = h ; // secondes avec h, m, s
       minutes = m ;
       secondes = s ; 
       normaliser() ;
  }
      
       public TimeDuration( long t){ // initialise heures, minutes, secondes 
       TimeDuration t ; // avec le temps t exprimé 
       t = conversionInverse(t) ;
       heures = t.heures ;
       minutes = t.minutes ;
       secondes = t.secondes ;
  }
       
   private long conversion(){
       return ((heures*60L)+minutes)*60+secondes ;
    }

    private TimeDuration conversionInverse(long t){
        TimeDuration te = new TimeDuration();
        te.secondes = (int)(t%60) ;
        t = t/60 ;
        te.minutes = (int)(t%60) ;
        te.heures = (int)(t/60) ;
        return te ;
    }

    private void normaliser(){
       long t = conversion() ;
       secondes = (int)(t%60) ;
       t = t/60 ;
       minutes = (int)(t%60) ;
       heures = (int)(t/60) ;
    }

    
       public void setHeures(int h){ heures = h ;}

   public void setMinutes(int m){ minutes = m ; normaliser() ;}

   public void setSecondes(int s){ secondes = s ; normaliser() ;}
   
   
      public TimeDuration ajouter( TimeDuration te){
      long t = conversion() + te.conversion() ;
      return conversionInverse(t) ; 
   }

   public TimeDuration ajouterUneSeconde(){
      long t = conversion() + new TimeDuration(0,0,1).conversion() ;
      return conversionInverse(t); 
   }
    
     public int compareA( TimeDuration te){ //
         
      long t1 = conversion();
      long t2 = te.conversion();
      return (int)(t1 – t2); 
   }
     
        public boolean egal( TimeDuration te){
      long t1 = conversion() ;
      long t2 = te.conversion() ;
      return t1 == t2 ; 
   }

     public String toString(){
      return heures+ ”h, ” +minutes+ ”m, ” +secondes+ ”s ”;
  }
   

     public class BadBadVadValueException extends Exception {
          public final double errValue ;
          public BadBadVadValueException(double errvalue) {
        this.errValue  = errValue ;
   }
           public String toString() {
      return super.toString() + " " + errValue ;
   }
  
     }

}  
